﻿namespace BandcampDownloader {

    internal enum FileType {
        Artwork,
        Track
    }
}