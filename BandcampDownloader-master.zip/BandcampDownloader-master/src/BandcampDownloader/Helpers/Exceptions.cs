﻿using System;

namespace BandcampDownloader {

    internal class CouldNotCheckForUpdatesException: Exception {
    }

    internal class NoAlbumFoundException: Exception {
    }
}