﻿namespace BandcampDownloader {

    internal enum LogType {
        VerboseInfo,
        Info,
        IntermediateSuccess,
        Success,
        Warning,
        Error,
    }
}